package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;
import pageObjects.AccountRegistrationPage;
import pageObjects.HomePage;
import testBase.BaseClass;

public class TC001_AccountRegistrationTest extends BaseClass {

    @Test(groups = {"Regression", "Master"})
    public void verify_account_registration() {
        logger.info("**** Starting TC001_AccountRegistrationTest ****");
        
        try {
            HomePage hp = new HomePage(driver);
            hp.clickMyAccount();
            logger.info("Clicked on MyAccount link");
            hp.clickRegister();
            logger.info("Clicked on Register link");
            
            AccountRegistrationPage regpage = new AccountRegistrationPage(driver);
            
            logger.info("Providing Customer details");
            regpage.setFirstName(randomString().toUpperCase());
            regpage.setLastName(randomString().toUpperCase());
            regpage.setEmail(randomString() + "@gmail.com"); 
            regpage.setTelephone(randomNumber());
            
            String pass = randomAlphaNumber();
            regpage.setPassword(pass); 
            regpage.setConfirmPassword(pass);
            regpage.setPrivacyPolicy();
            regpage.clickContinue();
            
            logger.info("Validating expected message");
            String confmsg = regpage.getConfirmationMsg();        
            
            if (confmsg.equals("Your Account Has Been Created!")) {
                Assert.assertTrue(true);
            } else {
                logger.error("Test Failed: Confirmation message did not match. Actual: " + confmsg);
                Assert.fail("Expected confirmation message not found.");
            }
        } catch (Exception e) {
            logger.error("Test Failed with Exception: " + e.getMessage());
            Assert.fail("Exception occurred: " + e.getMessage()); // Exposes exact failure reason
        }        
        logger.info("**** Finished TC001_AccountRegistrationTest ****");
    }
}