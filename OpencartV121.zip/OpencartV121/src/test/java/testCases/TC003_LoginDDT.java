package testCases;

import java.io.IOException;
import java.lang.invoke.StringConcatFactory;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import pageObjects.LoginPage;
import pageObjects.MyAccountPage;
import testBase.BaseClass;
import utilites.DataProviders;


public class TC003_LoginDDT extends BaseClass{

	@Test(dataProvider = "LoginData", dataProviderClass = DataProviders.class, groups = "DataDriven")		//getting data provieder from different class
	public void verify_loginDDT(String email, String pwd, String exp) throws IOException
	{
		logger.info("**** Starting TC003_LoginDDT  ****");
		
		try {
			HomePage hp = new HomePage(driver);
			hp.clickMyAccount();
			hp.clickLogin();
			
			
			// LoginPage
			LoginPage l = new LoginPage(driver);
			l.setEmail(email);
			l.setPassword(pwd);
			l.clickLoginBtn();
			
			/*
			 	Data is valid	--> login success - test pass - logout
			 	Data is valid	-->	login failed - test fail
			 	
			 	Data is invalid	-->	login success - test fail - logout
			 	Data is invalid	-->	login failed - test pass 
			 */
			
			MyAccountPage macc = new MyAccountPage(driver);
			boolean targetpage = macc.isMyAccountPageExist();
			
			if(exp.equalsIgnoreCase("Valid")) 
			{
				if(targetpage==true)
				{
					Assert.assertTrue(true);
					macc.clickLogout();
				}
				else {
					Assert.assertTrue(false);
				}
			}
			
			if(exp.equalsIgnoreCase("Invalid")) 
			{
				if(targetpage==true)
				{
					Assert.assertTrue(false);
					macc.clickLogout();
				}
				else {
					Assert.assertTrue(true);
				}
			}
			
		} catch (Exception e) {
			Assert.fail();
		}
		logger.info("**** Starting TC003_LoginDDT  ****");
		
		
		
		
		
		
		
		
		
		
		//Assert.assertTrue(targetpage);		// or use  --> Assert.assertEquals(targetpage, true, "Login failed");
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
