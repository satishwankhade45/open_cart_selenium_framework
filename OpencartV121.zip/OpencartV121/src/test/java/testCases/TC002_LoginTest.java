package testCases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import pageObjects.LoginPage;
import pageObjects.MyAccountPage;
import testBase.BaseClass;

public class TC002_LoginTest extends BaseClass
{
	@Test(groups = {"Sanity", "Master"})
	public void verify_login() throws IOException
	{
		
		logger.info("**** Starting TC002_LoginTest ****");
		
		try {
			// HomePage
			HomePage hp = new HomePage(driver);
			hp.clickMyAccount();
			hp.clickLogin();
			
			
			// LoginPage
			LoginPage l = new LoginPage(driver);
			l.setEmail(p.getProperty("email"));
			l.setPassword(p.getProperty("password"));
			l.clickLoginBtn();
			
			// MyAccountPage
			MyAccountPage macc = new MyAccountPage(driver);
			boolean targetpage = macc.isMyAccountPageExist();
			
			Assert.assertTrue(targetpage);		// or use  --> Assert.assertEquals(targetpage, true, "Login failed");
			
		} catch (Exception e) {
			Assert.fail();
		}
		logger.info("**** Finished TC002_LoginTest ****");
		
		
		
	}

}
