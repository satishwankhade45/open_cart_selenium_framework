package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.AccountRegistrationPage;
import pageObjects.HomePage;
import testBase.BaseClass;

public class TC001_AccountRegistrationTest extends BaseClass {


	
	@Test(groups = {"Regression", "Master"})
	public void verify_account_registration() 
	{
		logger.info("**** Starting TC001_AccountRegistrationTest ****");
		
		try {
			HomePage hp = new HomePage(driver);
			hp.clickMyAccount();
			logger.info("click on MyAccount link");
			hp.clickRegister();
			logger.info("click on Register link");
			
			AccountRegistrationPage regpage = new AccountRegistrationPage(driver);
			
			logger.info("Providing Customer details");
			regpage.setFirstName(randomString().toUpperCase());
			regpage.setLastName(randomString().toUpperCase());
			regpage.setEmail(randomString()+"@gmail.com");		//"satasat@gmail.com"
			regpage.setTelephone(randomNumber());
			
			String pass = randomAlphaNumber();
			regpage.setPassword(pass);		//"xyz12356"
			regpage.setConfirmPassword(pass);
			regpage.setPrivacyPolicy();
			regpage.clickContinue();
			
			logger.info("Validating  expected message");
			
			String confmsg = regpage.getConfirmationMsg();		
			
			if(confmsg.equals("Your Account Has Been Created!"))
			{
				Assert.assertTrue(true);
			}
			else {
				logger.error("Test Failed...");
				logger.debug("Debug logs...");
				Assert.assertTrue(false);
			}
		} catch (Exception e) {
			Assert.fail();
		}		
	}
	
	
	

	
	
	
	
	
	
	
	
	
}
